<html>
  <head>
    <title>Josh Haefner Chapter 3</title>
  </head>
  <body>
    <?php
    echo ("Question #1<br>");
    $num1 = 22;
    $num2 = 11;
    echo ("First Number: $num1<br>Second Number: $num2<br><br>");

    echo ("Question #2<br>");
    $my_name = "Josh Haefner";
    echo ("Hello $my_name<br><br>");

    echo ("Question #3<br>");
    define("ACCELERATION_DUE_TO_GRAVITY", 9.81);
    echo (ACCELERATION_DUE_TO_GRAVITY);

    ?>
  </body>
</html>