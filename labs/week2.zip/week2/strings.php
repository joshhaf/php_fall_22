<html>
  <head>
    <title>Josh Haefner Chapter 4</title>
  </head>
  <body>
    <?php
    echo ("Question #1<br>");
    $first_name = "Josh";
    $last_name = "Haefner";
    $different_last_name = "O'Connor";

    echo ($first_name . " $last_name<br><br>");

    echo ("Questiokn #2<br>");
    echo ("$last_name, $first_name<br><br>");

    echo ("Question #3<br>");
    echo ("$first_name $different_last_name");
;    ?>
  </body>
</html>